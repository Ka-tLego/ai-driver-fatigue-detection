# Flutter app integration files

This folder contains Dart source files to merge into an existing Flutter project.
It is not a complete generated Flutter scaffold because your team's existing `pubspec.yaml`,
assets, and app entry point should be preserved.

## Files
- `lib/config/api_config.dart`
- `lib/services/api_service.dart`
- `lib/screens/backend_demo_screen.dart`
- `lib/main_backend_demo.dart`

## Test
From the Flutter project root, after adding `http: ^1.2.2` and running `flutter pub get`:
- Emulator: `flutter run -t lib/main_backend_demo.dart`
- Physical phone: `flutter run -t lib/main_backend_demo.dart --dart-define=API_BASE_URL=http://192.168.96.31:3000/api`
- Windows: `flutter run -d windows -t lib/main_backend_demo.dart`
- Web: `flutter run -d chrome -t lib/main_backend_demo.dart`

Backend defaults:
- Android emulator: `http://10.0.2.2:3000/api`
- Windows/web on same computer: `http://localhost:3000/api`
- Physical phone: pass your computer's LAN IP via `API_BASE_URL`.

For Android HTTP development, ensure `INTERNET` permission in AndroidManifest.xml and if needed
allow cleartext traffic in debug. For Flutter web, configure backend CORS to match the app origin.
