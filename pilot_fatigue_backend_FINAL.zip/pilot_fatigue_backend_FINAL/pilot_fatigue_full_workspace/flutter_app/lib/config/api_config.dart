import 'package:flutter/foundation.dart';

/// Backend address configuration.
///
/// Emulator: default Android URL is 10.0.2.2.
/// Physical phone: launch with --dart-define=API_BASE_URL=http://192.168.96.31:3000/api
/// Windows/web: localhost when backend runs on the same computer.
class ApiConfig {
  static String get baseUrl {
    const override = String.fromEnvironment('API_BASE_URL');
    if (override.isNotEmpty) return _trimTrailingSlash(override);

    if (kIsWeb) return 'http://localhost:3000/api';

    switch (defaultTargetPlatform) {
      case TargetPlatform.android:
        return 'http://10.0.2.2:3000/api';
      case TargetPlatform.windows:
      case TargetPlatform.linux:
      case TargetPlatform.macOS:
      case TargetPlatform.iOS:
        return 'http://localhost:3000/api';
      case TargetPlatform.fuchsia:
        return 'http://localhost:3000/api';
    }
  }

  static String _trimTrailingSlash(String value) {
    while (value.endsWith('/')) {
      value = value.substring(0, value.length - 1);
    }
    return value;
  }
}
