import 'package:flutter/material.dart';
import 'screens/backend_demo_screen.dart';

/// Optional demo entry point. Run with:
/// flutter run -t lib/main_backend_demo.dart
void main() {
  runApp(const BackendDemoApp());
}

class BackendDemoApp extends StatelessWidget {
  const BackendDemoApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Pilot Fatigue Backend Test',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.blue),
        useMaterial3: true,
      ),
      home: const BackendDemoScreen(),
    );
  }
}
