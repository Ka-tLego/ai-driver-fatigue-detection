import 'package:flutter/material.dart';
import '../services/api_service.dart';

/// A temporary integration/test screen. You can use it to verify all core
/// backend endpoints before wiring these calls into your team's real screens.
class BackendDemoScreen extends StatefulWidget {
  const BackendDemoScreen({super.key});

  @override
  State<BackendDemoScreen> createState() => _BackendDemoScreenState();
}

class _BackendDemoScreenState extends State<BackendDemoScreen> {
  final ApiService _api = ApiService();
  final TextEditingController _pilotController =
      TextEditingController(text: 'pilot-001');
  final TextEditingController _sessionController = TextEditingController();
  final TextEditingController _heartController =
      TextEditingController(text: '82');
  final TextEditingController _blinkController =
      TextEditingController(text: '18');
  final TextEditingController _earController =
      TextEditingController(text: '0.27');
  String _fatigueLevel = 'normal';
  String _severity = 'Warning';
  String _status = 'active';
  bool _busy = false;
  String _output = 'Tap “Check backend” to test the connection.';

  @override
  void dispose() {
    _api.dispose();
    _pilotController.dispose();
    _sessionController.dispose();
    _heartController.dispose();
    _blinkController.dispose();
    _earController.dispose();
    super.dispose();
  }

  Future<void> _run(Future<Map<String, dynamic>> Function() action) async {
    setState(() {
      _busy = true;
      _output = 'Working…';
    });
    try {
      final result = await action();
      if (!mounted) return;
      setState(() => _output = result.toString());
    } catch (e) {
      if (!mounted) return;
      setState(() => _output = 'ERROR: $e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  String get _sessionId => _sessionController.text.trim();

  double? _parse(TextEditingController controller) =>
      double.tryParse(controller.text.trim());

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Fatigue Backend Test')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text(
            'Temporary integration screen',
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 6),
          const Text(
            'Use this screen to test the backend. Values entered here are '
            'test values, not live sensor measurements.',
          ),
          const SizedBox(height: 16),
          _button('Check backend', () => _run(_api.healthCheck)),
          const SizedBox(height: 12),
          TextField(
            controller: _pilotController,
            decoration: const InputDecoration(
              labelText: 'Pilot ID',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 8),
          _button('Create session', () => _run(() async {
                final result = await _api.createSession(
                  pilotId: _pilotController.text.trim(),
                );
                final data = result['data'];
                if (data is Map && data['_id'] != null) {
                  _sessionController.text = data['_id'].toString();
                }
                return result;
              })),
          const SizedBox(height: 12),
          TextField(
            controller: _sessionController,
            decoration: const InputDecoration(
              labelText: 'Session ID',
              hintText: 'Paste the _id returned by the backend',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 8),
          _button('Retrieve session', () => _run(() {
                if (_sessionId.isEmpty) {
                  throw Exception('Enter a session ID first.');
                }
                return _api.getSession(_sessionId);
              })),
          const SizedBox(height: 8),
          DropdownButtonFormField<String>(
            value: _status,
            decoration: const InputDecoration(
              labelText: 'Session status',
              border: OutlineInputBorder(),
            ),
            items: const [
              DropdownMenuItem(value: 'active', child: Text('active / resume')),
              DropdownMenuItem(value: 'paused', child: Text('paused')),
              DropdownMenuItem(value: 'ended', child: Text('ended')),
            ],
            onChanged: (v) => setState(() => _status = v ?? 'active'),
          ),
          const SizedBox(height: 8),
          _button('Update session status', () => _run(() {
                if (_sessionId.isEmpty) {
                  throw Exception('Enter a session ID first.');
                }
                return _api.updateSession(
                  sessionId: _sessionId,
                  status: _status,
                );
              })),
          const Divider(height: 32),
          const Text(
            'Test sensor reading',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 8),
          TextField(
            controller: _heartController,
            keyboardType: const TextInputType.numberWithOptions(decimal: true),
            decoration: const InputDecoration(
              labelText: 'Heart rate (BPM)',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 8),
          TextField(
            controller: _blinkController,
            keyboardType: const TextInputType.numberWithOptions(decimal: true),
            decoration: const InputDecoration(
              labelText: 'Blink rate per minute',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 8),
          TextField(
            controller: _earController,
            keyboardType: const TextInputType.numberWithOptions(decimal: true),
            decoration: const InputDecoration(
              labelText: 'EAR',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 8),
          DropdownButtonFormField<String>(
            value: _fatigueLevel,
            decoration: const InputDecoration(
              labelText: 'Fatigue level',
              border: OutlineInputBorder(),
            ),
            items: const [
              DropdownMenuItem(value: 'normal', child: Text('normal')),
              DropdownMenuItem(value: 'warning', child: Text('warning')),
              DropdownMenuItem(value: 'high', child: Text('high')),
              DropdownMenuItem(value: 'critical', child: Text('critical')),
            ],
            onChanged: (v) => setState(() => _fatigueLevel = v ?? 'normal'),
          ),
          const SizedBox(height: 8),
          _button('Send test reading', () => _run(() {
                if (_sessionId.isEmpty) {
                  throw Exception('Create or enter a session ID first.');
                }
                return _api.sendReading(
                  sessionId: _sessionId,
                  heartRateBpm: _parse(_heartController),
                  blinkRatePerMinute: _parse(_blinkController),
                  ear: _parse(_earController),
                  fatigueLevel: _fatigueLevel,
                );
              })),
          const Divider(height: 32),
          const Text(
            'Test fatigue event',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 8),
          DropdownButtonFormField<String>(
            value: _severity,
            decoration: const InputDecoration(
              labelText: 'Severity',
              border: OutlineInputBorder(),
            ),
            items: const [
              DropdownMenuItem(value: 'Warning', child: Text('Warning')),
              DropdownMenuItem(value: 'High', child: Text('High')),
              DropdownMenuItem(value: 'Critical', child: Text('Critical')),
            ],
            onChanged: (v) => setState(() => _severity = v ?? 'Warning'),
          ),
          const SizedBox(height: 8),
          _button('Create test fatigue event', () => _run(() {
                if (_sessionId.isEmpty) {
                  throw Exception('Create or enter a session ID first.');
                }
                return _api.createFatigueEvent(
                  sessionId: _sessionId,
                  severity: _severity,
                  message: 'Test event from Flutter demo screen',
                  fatigueLevel: _fatigueLevel,
                );
              })),
          const SizedBox(height: 8),
          _button('List fatigue events', () => _run(() {
                return _api.listEvents(
                  sessionId: _sessionId.isEmpty ? null : _sessionId,
                );
              })),
          const SizedBox(height: 16),
          const Text(
            'Response',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              border: Border.all(color: Theme.of(context).dividerColor),
              borderRadius: BorderRadius.circular(8),
            ),
            child: SelectableText(_output),
          ),
          if (_busy) const LinearProgressIndicator(),
        ],
      ),
    );
  }

  Widget _button(String label, VoidCallback onPressed) {
    return FilledButton(
      onPressed: _busy ? null : onPressed,
      child: Text(label),
    );
  }
}
