import 'dart:convert';
import 'package:http/http.dart' as http;
import '../config/api_config.dart';

/// HTTP client for the pilot-fatigue backend.
/// Throws an exception for non-2xx responses so the UI can display errors.
class ApiService {
  ApiService({http.Client? client})
      : _client = client ?? http.Client();

  final http.Client _client;
  String get _baseUrl => ApiConfig.baseUrl;

  Future<Map<String, dynamic>> healthCheck() =>
      _getObject('$_baseUrl/health');

  Future<Map<String, dynamic>> createSession({
    required String pilotId,
    String? notes,
  }) async {
    final body = <String, dynamic>{'pilotId': pilotId};
    if (notes != null && notes.trim().isNotEmpty) {
      body['notes'] = notes.trim();
    }
    return _postObject('$_baseUrl/sessions', body);
  }

  Future<Map<String, dynamic>> listSessions() =>
      _getObject('$_baseUrl/sessions');

  Future<Map<String, dynamic>> getSession(String sessionId) =>
      _getObject('$_baseUrl/sessions/${Uri.encodeComponent(sessionId)}');

  Future<Map<String, dynamic>> updateSession({
    required String sessionId,
    String? status,
    String? autopilotStatus,
    String? notes,
  }) async {
    final body = <String, dynamic>{};
    if (status != null) body['status'] = status;
    if (autopilotStatus != null) body['autopilotStatus'] = autopilotStatus;
    if (notes != null) body['notes'] = notes;
    if (body.isEmpty) {
      throw ArgumentError('Provide at least one session field to update.');
    }
    return _patchObject(
      '$_baseUrl/sessions/${Uri.encodeComponent(sessionId)}',
      body,
    );
  }

  Future<Map<String, dynamic>> sendReading({
    required String sessionId,
    double? heartRateBpm,
    double? blinkRatePerMinute,
    double? ear,
    String? fatigueLevel,
    String source = 'flutter_app',
  }) async {
    final body = <String, dynamic>{'source': source};
    if (heartRateBpm != null) body['heartRateBpm'] = heartRateBpm;
    if (blinkRatePerMinute != null) {
      body['blinkRatePerMinute'] = blinkRatePerMinute;
    }
    if (ear != null) body['ear'] = ear;
    if (fatigueLevel != null) body['fatigueLevel'] = fatigueLevel;

    return _postObject(
      '$_baseUrl/sessions/${Uri.encodeComponent(sessionId)}/readings',
      body,
    );
  }

  Future<Map<String, dynamic>> createFatigueEvent({
    required String sessionId,
    required String severity,
    required String message,
    String? fatigueLevel,
  }) async {
    final body = <String, dynamic>{
      'sessionId': sessionId,
      'severity': severity,
      'message': message,
    };
    if (fatigueLevel != null) body['fatigueLevel'] = fatigueLevel;
    return _postObject('$_baseUrl/events', body);
  }

  Future<Map<String, dynamic>> listEvents({
    String? sessionId,
  }) async {
    final uri = Uri.parse('$_baseUrl/events');
    final withQuery = sessionId == null
        ? uri
        : uri.replace(queryParameters: {'sessionId': sessionId});
    return _getObject(withQuery.toString());
  }

  Future<Map<String, dynamic>> _getObject(String url) async {
    final response = await _client
        .get(Uri.parse(url), headers: _headers)
        .timeout(const Duration(seconds: 15));
    return _handleResponse(response);
  }

  Future<Map<String, dynamic>> _postObject(
    String url,
    Map<String, dynamic> body,
  ) async {
    final response = await _client
        .post(Uri.parse(url), headers: _headers, body: jsonEncode(body))
        .timeout(const Duration(seconds: 15));
    return _handleResponse(response);
  }

  Future<Map<String, dynamic>> _patchObject(
    String url,
    Map<String, dynamic> body,
  ) async {
    final response = await _client
        .patch(Uri.parse(url), headers: _headers, body: jsonEncode(body))
        .timeout(const Duration(seconds: 15));
    return _handleResponse(response);
  }

  static const _headers = {
    'Content-Type': 'application/json',
    'Accept': 'application/json',
  };

  Map<String, dynamic> _handleResponse(http.Response response) {
    dynamic decoded;
    try {
      decoded = jsonDecode(response.body);
    } catch (_) {
      decoded = {'message': response.body};
    }

    if (response.statusCode < 200 || response.statusCode >= 300) {
      final message = decoded is Map
          ? (decoded['message'] ?? decoded['error'] ?? response.body)
          : response.body;
      throw Exception('HTTP ${response.statusCode}: $message');
    }

    if (decoded is Map<String, dynamic>) return decoded;
    return {'data': decoded};
  }

  void dispose() => _client.close();
}
