# Pilot Fatigue Detection - Backend & Database

**Role: Member 6 - Backend & Database**

REST API and MongoDB database that store monitoring information and fatigue events produced by the Pilot Fatigue Detection Flutter application.

The backend **receives, validates, stores and returns** data. It does not detect fatigue itself: the Flutter app decides the fatigue level and sends it, and the backend stores it as received.

---

## Features

- Monitoring sessions with start and end timestamps
- Monitoring state: `active`, `paused`, `ended`
- Autopilot status: `unknown`, `on`, `off`
- Sensor readings: heart rate (BPM), blink rate (per minute), EAR (eye aspect ratio), fatigue level and optional fatigue score
- Fatigue events with severity `Warning`, `High` or `Critical`
- Session summary: duration, counts, averages, peak fatigue level
- Input validation with clear error messages
- Automated API tests and a sample-data script

## Tech stack

| Part | Technology |
|---|---|
| Runtime | Node.js 18+ |
| Web framework | Express 4 |
| Database | MongoDB (Community Server) |
| ODM | Mongoose 8 |
| Security / hardening | helmet, cors, express-rate-limit (300 requests/min) |
| Tests | Node built-in test runner + supertest |

## Project structure

```
pilot_fatigue_full_workspace/
├── start_backend.ps1            # Windows start script
├── backend/
│   ├── src/
│   │   ├── server.js            # Starts the server, connects to MongoDB
│   │   ├── app.js               # Express app, middleware, routes, error handling
│   │   ├── config/db.js         # MongoDB connection
│   │   ├── models/              # MonitoringSession, SensorReading, FatigueEvent
│   │   └── routes/              # sessionRoutes, readingRoutes, eventRoutes
│   ├── scripts/seed.js          # Posts sample data to a running backend
│   ├── test/                    # Automated API tests
│   ├── DATABASE.md              # Database design
│   ├── .env.example
│   └── package.json
└── flutter_app/                 # Integration files for the Flutter team
```

---

## Getting started (Windows)

### Prerequisites
- [Node.js](https://nodejs.org) 18 or newer
- [MongoDB Community Server](https://www.mongodb.com/try/download/community), installed and running

### Run
Open PowerShell in the folder that contains `backend`, `flutter_app` and `start_backend.ps1`:

```powershell
Set-ExecutionPolicy -Scope Process Bypass
.\start_backend.ps1
```

The script creates `.env` if needed, installs packages, and starts the server. Or do it manually:

```powershell
cd backend
Copy-Item .env.example .env     # skip if .env already exists
npm install
npm run dev                     # development (auto-restart); use "npm start" for plain start
```

When it works you will see:

```
Connected to MongoDB
Fatigue backend listening on port 3000
Health check: http://localhost:3000/api/health
```

Keep this window open - closing it stops the backend.

### Configuration (`backend/.env`)

| Variable | Default | Description |
|---|---|---|
| `PORT` | `3000` | Port the API listens on |
| `MONGODB_URI` | `mongodb://127.0.0.1:27017/pilot_fatigue` | MongoDB connection string |
| `CORS_ORIGIN` | *(empty = allow all)* | Comma-separated allowed origins (for Flutter web) |

---

## API reference

Base URL: `http://localhost:3000/api`

All requests and responses are JSON. Responses have the form `{ "success": true, "message": "...", "data": ... }`.

| Method | Endpoint | Description |
|---|---|---|
| GET | `/health` | Server health check |
| POST | `/sessions` | Start a monitoring session |
| GET | `/sessions` | List sessions (newest first, max 100) |
| GET | `/sessions/:id` | One session with its readings and events |
| GET | `/sessions/:id/summary` | Duration, counts, averages, peak level |
| PATCH | `/sessions/:id` | Update status, autopilot status or notes |
| POST | `/sessions/:id/readings` | Store a sensor reading |
| GET | `/sessions/:id/readings?limit=100` | List readings (newest first, max 1000) |
| POST | `/events` | Store a fatigue event |
| GET | `/events?sessionId=<id>` | List events (newest first, max 200) |

### Create a session
`POST /sessions`
```json
{ "pilotId": "pilot-001", "notes": "optional" }
```
Returns the new session with `status: "active"` and `startedAt`.

### Update session state
`PATCH /sessions/:id` - any of:
```json
{ "status": "paused", "autopilotStatus": "on", "notes": "text" }
```
`status`: `active` | `paused` | `ended` (ending sets `endedAt`; resuming clears it).
`autopilotStatus`: `unknown` | `on` | `off`.

### Store a reading
`POST /sessions/:id/readings` - all fields optional:
```json
{
  "heartRateBpm": 72,
  "blinkRatePerMinute": 16,
  "ear": 0.28,
  "fatigueLevel": "normal",
  "fatigueScore": 12,
  "source": "flutter_app",
  "recordedAt": "2026-10-12T21:30:00Z"
}
```
Limits: `heartRateBpm` 0-300, `blinkRatePerMinute` 0-200, `ear` 0-1, `fatigueScore` 0-100, `fatigueLevel` one of `normal|warning|high|critical`. `recordedAt` defaults to now.

### Store a fatigue event
`POST /events`
```json
{
  "sessionId": "<session _id>",
  "severity": "High",
  "message": "Eyes closing repeatedly",
  "fatigueLevel": "high"
}
```
`severity` must be `Warning`, `High` or `Critical`.

### Session summary
`GET /sessions/:id/summary` returns, for example:
```json
{
  "sessionId": "...",
  "status": "ended",
  "durationSeconds": 120,
  "readingCount": 4,
  "eventCount": 3,
  "peakLevel": "critical",
  "averages": { "heartRateBpm": 63.5, "blinkRatePerMinute": 26.5, "ear": 0.22, "fatigueScore": null },
  "levelCounts": { "normal": 1, "warning": 1, "high": 1, "critical": 1 },
  "severityCounts": { "Warning": 1, "High": 1, "Critical": 1 }
}
```

### Error responses

| Status | Meaning |
|---|---|
| 400 | Invalid input (bad ID, out-of-range value, unknown level/severity/status) |
| 404 | Session not found, or unknown route |
| 409 | Session has ended - no more readings accepted |
| 429 | Too many requests (rate limit) |
| 500 | Internal server error |

### Example calls (PowerShell)

```powershell
# Create a session
$s = Invoke-RestMethod -Method Post -Uri http://localhost:3000/api/sessions `
     -ContentType "application/json" -Body '{"pilotId":"pilot-001"}'
$id = $s.data._id

# Send a reading
Invoke-RestMethod -Method Post -Uri "http://localhost:3000/api/sessions/$id/readings" `
  -ContentType "application/json" `
  -Body '{"heartRateBpm":72,"blinkRatePerMinute":16,"ear":0.28,"fatigueLevel":"normal"}'

# Store an event
Invoke-RestMethod -Method Post -Uri http://localhost:3000/api/events `
  -ContentType "application/json" `
  -Body ('{"sessionId":"' + $id + '","severity":"Warning","message":"Eyes drooping"}')

# Read it back
Invoke-RestMethod http://localhost:3000/api/sessions/$id/summary
```

---

## Database design

MongoDB database `pilot_fatigue` with three collections linked by `sessionId`:

```
monitoringsessions 1 ──< sensorreadings
                   1 ──< fatigueevents
```

**monitoringsessions** - `_id`, `pilotId`, `status`, `autopilotStatus`, `notes`, `startedAt`, `endedAt`, `createdAt`, `updatedAt`

**sensorreadings** - `sessionId` (indexed), `heartRateBpm`, `blinkRatePerMinute`, `ear`, `fatigueLevel`, `fatigueScore`, `source`, `recordedAt`. Compound index on `{ sessionId, recordedAt }`.

**fatigueevents** - `sessionId` (indexed), `severity`, `message`, `fatigueLevel`, `occurredAt`

Full field tables are in [`backend/DATABASE.md`](backend/DATABASE.md). To browse the data visually, open MongoDB Compass, connect to `mongodb://127.0.0.1:27017` and open the `pilot_fatigue` database.

---

## Testing

```powershell
cd backend
npm test          # automated API tests (no database needed)
npm run seed      # sends sample data to the running backend
```

`npm run seed` creates a session with 4 readings and 3 events (Warning, High, Critical), cycles it through paused/active/ended, and prints the summary. It prints a link to view the stored session in your browser.

## Connecting the Flutter app

The Flutter client files are in `flutter_app/lib` (`api_config.dart`, `api_service.dart`, a test screen). Base URLs:

| Where the app runs | Base URL |
|---|---|
| Android emulator | `http://10.0.2.2:3000/api` |
| Windows desktop / Chrome | `http://localhost:3000/api` |
| Physical phone (same Wi-Fi) | `http://<your-PC-IP>:3000/api` (find the IP with `ipconfig`) |

For a phone, also allow Node.js through Windows Firewall on private networks. Typical app flow:

1. `POST /sessions` when monitoring starts - keep the returned `_id`
2. `POST /sessions/:id/readings` regularly with the latest measurements
3. `POST /events` when a Warning/High/Critical fatigue event occurs
4. `PATCH /sessions/:id` when monitoring is paused, resumed or ended, or autopilot status changes

---

## Troubleshooting

| Problem | Fix |
|---|---|
| `EADDRINUSE ... port 3000` | The backend is already running. Check `http://localhost:3000/api/health`, or stop the old one, or change `PORT` in `.env` |
| `cd backend` says path not found | You are one folder too high. Run `cd .\pilot_fatigue_full_workspace` first (unzipping can nest the folder) |
| Script "is not digitally signed" | `Set-ExecutionPolicy -Scope Process Bypass`, then `Get-ChildItem -Recurse . -Include *.ps1 \| Unblock-File` |
| `MongoServerSelectionError` / cannot connect | MongoDB is not running. Start the MongoDB service, and check `MONGODB_URI` in `.env` |
| Browser shows "refused to connect" | The backend window was closed. Start it again and leave it open |
| `<PID>` or `<id>` errors in PowerShell | Placeholders in angle brackets must be replaced with real values, not typed literally |

## Limitations

- The backend stores data as sent; it performs no fatigue detection.
- No authentication: suitable for a local/team prototype, not for production. Add authentication and HTTPS before any real deployment.
- Automated tests use an in-memory stand-in for the models; verify against your real MongoDB with `npm run seed`.
