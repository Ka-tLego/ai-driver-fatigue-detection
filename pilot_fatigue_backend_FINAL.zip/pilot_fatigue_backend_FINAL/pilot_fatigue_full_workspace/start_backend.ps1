# Starts the backend. Run from the workspace root:  .\start_backend.ps1
# Handles the "port 3000 already in use" case for you.
$ErrorActionPreference = 'Stop'
Set-Location (Join-Path $PSScriptRoot 'backend')
if (-not (Test-Path .env)) { Copy-Item .env.example .env; Write-Host 'Created .env' }
if (-not (Test-Path node_modules)) { npm install }

$port = 3000
$line = Get-Content .env | Where-Object { $_ -match '^PORT=' } | Select-Object -First 1
if ($line) { $port = [int]($line -replace 'PORT=', '') }

$inUse = Get-NetTCPConnection -LocalPort $port -State Listen -ErrorAction SilentlyContinue
if ($inUse) {
  try {
    $h = Invoke-RestMethod "http://localhost:$port/api/health" -TimeoutSec 3
    Write-Host "Backend is ALREADY running on port $port ($($h.message))." -ForegroundColor Green
    Write-Host "Dashboard: http://localhost:$port/"
    Start-Process "http://localhost:$port/"
    exit 0
  } catch {
    Write-Host "Port $port is used by another program (PID $($inUse[0].OwningProcess)). Close it or change PORT in backend\.env" -ForegroundColor Red
    exit 1
  }
}
npm run dev
